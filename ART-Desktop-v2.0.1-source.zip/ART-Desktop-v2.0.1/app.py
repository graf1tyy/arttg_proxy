from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QLockFile
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication, QMessageBox

from art.config import app_data_dir
from art.ui import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("ART")
    app.setOrganizationName("ART")

    # A second ART window could start another hidden engine on a new port.
    # A process lock prevents duplicate instances and orphaned transports.
    lock = QLockFile(str(app_data_dir() / "art.lock"))
    if not lock.tryLock(0):
        QMessageBox.information(None, "ART уже запущен", "ART уже работает. Проверь системный трей или открой существующее окно.")
        return 0

    icon_path = Path(__file__).resolve().parent / "assets" / "art.ico"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))
    window = MainWindow()
    if "--smoke-test" in sys.argv[1:]:
        # CI-only startup check: instantiate and paint the real window without
        # starting the network engine or leaving an interactive window open.
        window.show()
        app.processEvents()
        window.close()
        app.processEvents()
        lock.unlock()
        return 0
    window.show()
    result = app.exec()
    lock.unlock()
    return result


if __name__ == "__main__":
    raise SystemExit(main())
