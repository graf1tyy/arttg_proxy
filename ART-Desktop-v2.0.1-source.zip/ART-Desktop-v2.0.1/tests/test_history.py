import tempfile
import unittest
from pathlib import Path

from art.catalog import parse_proxy_link
from art.history import apply_history, load_history, record_feedback


class HistoryTests(unittest.TestCase):
    def make_candidate(self):
        return parse_proxy_link(
            "tg://proxy?server=149.154.167.50&port=443&secret=0123456789abcdef0123456789abcdef"
        )

    def test_good_feedback_persists_and_boosts(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "history.json"
            candidate = self.make_candidate()
            record_feedback(candidate, "good", path)
            self.assertEqual(candidate.user_feedback, "good")
            self.assertEqual(candidate.user_good_count, 1)
            loaded = self.make_candidate()
            apply_history([loaded], load_history(path))
            self.assertEqual(loaded.user_feedback, "good")
            self.assertEqual(loaded.user_good_count, 1)

    def test_ads_feedback_blocks_auto_recommendation(self):
        with tempfile.TemporaryDirectory() as tmp:
            candidate = self.make_candidate()
            candidate.verified = True
            candidate.ads_status = "none"
            candidate.local_reachable = True
            candidate.success_rate = .99
            record_feedback(candidate, "ads", Path(tmp) / "history.json")
            self.assertEqual(candidate.ads_status, "present")
            self.assertFalse(candidate.eligible_for_auto)

    def test_good_feedback_records_user_observed_clean_ads_status(self):
        with tempfile.TemporaryDirectory() as tmp:
            candidate = self.make_candidate()
            candidate.verified = True
            candidate.local_reachable = True
            candidate.success_rate = .45
            self.assertEqual(candidate.ads_status, "unknown")
            path = Path(tmp) / "history.json"
            record_feedback(candidate, "good", path)
            self.assertEqual(candidate.ads_status, "none")
            self.assertTrue(candidate.verified)
            self.assertTrue(candidate.local_reachable)
            self.assertTrue(candidate.user_review_fresh)
            self.assertTrue(candidate.eligible_for_auto)
            restored = self.make_candidate()
            apply_history([restored], load_history(path))
            self.assertEqual(restored.ads_status, "none")
            self.assertTrue(restored.verified)
            self.assertTrue(restored.local_reachable)
            self.assertTrue(restored.user_review_fresh)
            self.assertTrue(restored.eligible_for_auto)

    def test_old_good_review_keeps_rank_but_expires_auto_eligibility(self):
        from datetime import datetime, timezone, timedelta
        from art.history import _proxy_id
        candidate = self.make_candidate()
        candidate.ads_status = "unknown"
        key = _proxy_id(candidate)
        old = (datetime.now(timezone.utc) - timedelta(days=10)).isoformat()
        apply_history([candidate], {key: {
            "feedback": "good", "ads_status": "none", "good_count": 3,
            "updated_at": old,
        }})
        self.assertEqual(candidate.user_feedback, "good")
        self.assertEqual(candidate.user_good_count, 3)
        self.assertFalse(candidate.verified)
        self.assertIsNone(candidate.local_reachable)
        self.assertFalse(candidate.user_review_fresh)
        self.assertEqual(candidate.ads_status, "unknown")
        candidate.local_reachable = True
        candidate.success_rate = .45
        self.assertFalse(candidate.eligible_for_auto)

    def test_current_source_ad_warning_overrides_old_good_feedback(self):
        candidate = self.make_candidate()
        candidate.ads_status = "present"
        from art.history import _proxy_id
        key = _proxy_id(candidate)
        apply_history([candidate], {key: {"feedback": "good", "ads_status": "none", "good_count": 1}})
        self.assertEqual(candidate.ads_status, "present")
        self.assertFalse(candidate.eligible_for_auto)

    def test_corrupt_history_counters_do_not_crash(self):
        candidate = self.make_candidate()
        key = __import__("art.history", fromlist=["_proxy_id"])._proxy_id(candidate)
        apply_history([candidate], {key: {"feedback": "good", "good_count": "broken", "bad_count": float("inf")}})
        self.assertEqual(candidate.user_good_count, 0)
        self.assertEqual(candidate.user_bad_count, 0)

    def test_current_ad_finding_is_not_overwritten_by_good_review(self):
        with tempfile.TemporaryDirectory() as tmp:
            candidate = self.make_candidate()
            candidate.ads_status = "present"
            record_feedback(candidate, "good", Path(tmp) / "history.json")
            self.assertEqual(candidate.ads_status, "present")
            self.assertFalse(candidate.eligible_for_auto)

    def test_bad_feedback_removes_from_auto_recommendation(self):
        candidate = self.make_candidate()
        candidate.verified = True
        candidate.ads_status = "none"
        candidate.local_reachable = True
        candidate.success_rate = .99
        candidate.user_feedback = "bad"
        self.assertFalse(candidate.eligible_for_auto)


if __name__ == "__main__":
    unittest.main()
