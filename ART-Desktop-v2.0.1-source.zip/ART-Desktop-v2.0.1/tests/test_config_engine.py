import tempfile
import unittest
from pathlib import Path

from art.config import AppConfig, load_config, save_config
from art.engine import build_engine_args, proxy_uri, find_free_port, parse_engine_telemetry, _redact_line


class ConfigEngineTests(unittest.TestCase):
    def test_round_trip_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "settings.json"
            cfg = AppConfig(port=1455, pool_size=6, worker_domains=("edge.example.workers.dev",), cloudflare_domains=("mycf.example",))
            save_config(cfg, path)
            loaded = load_config(path)
            self.assertEqual(loaded.port, 1455)
            self.assertEqual(loaded.pool_size, 6)
            self.assertEqual(loaded.worker_domains, ("edge.example.workers.dev",))
            self.assertEqual(loaded.host, "127.0.0.1")


    def test_non_object_settings_are_recovered(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "settings.json"
            path.write_text("[]", encoding="utf-8")
            loaded = load_config(path)
            self.assertEqual(loaded.host, "127.0.0.1")
            self.assertTrue(path.exists())
            self.assertTrue(list(Path(tmp).glob("settings.invalid.*.json")))

    def test_invalid_custom_domains_are_removed(self):
        cfg = AppConfig(worker_domains=("-bad.example", "good.example", "bad..example"))
        cfg.normalise()
        self.assertEqual(cfg.worker_domains, ("good.example",))

    def test_invalid_host_is_forced_to_loopback(self):
        cfg = AppConfig(host="0.0.0.0")
        cfg.normalise()
        self.assertEqual(cfg.host, "127.0.0.1")

    def test_secret_created_and_proxy_uri_is_local(self):
        cfg = AppConfig(secret="invalid")
        cfg.normalise()
        self.assertEqual(len(cfg.secret), 32)
        self.assertIn("server=127.0.0.1", proxy_uri(cfg))
        self.assertIn("secret=dd" + cfg.secret, proxy_uri(cfg))

    def test_engine_arguments_use_supported_options(self):
        cfg = AppConfig(port=1443, pool_size=4, cloudflare_enabled=True, media_h2_enabled=True, worker_domains=("edge.example.workers.dev",), cloudflare_domains=("mycf.example",))
        args = build_engine_args(cfg, Path("C:/Users/Test/AppData/ART/engine.log"))
        self.assertIn("--host", args)
        self.assertIn("127.0.0.1", args)
        self.assertIn("--port", args)
        self.assertIn("--cfproxy-worker-domain", args)
        self.assertIn("--cfproxy-domain", args)
        self.assertNotIn("--portable", args)
        self.assertNotIn("--default-domains", args)
        self.assertNotIn("--no-cfproxy", args)
        self.assertNotIn("--no-h2", args)

    def test_engine_disable_options(self):
        cfg = AppConfig(cloudflare_enabled=False, media_h2_enabled=False)
        args = build_engine_args(cfg, Path("engine.log"))
        self.assertIn("--no-cfproxy", args)
        self.assertIn("--no-h2", args)


    def test_failed_fallback_attempt_is_not_reported_as_active_route(self):
        log = "[127.0.0.1] DC2 -> trying CF proxy\n[127.0.0.1] DC2 CF proxy failed: TimeoutError()\n"
        result = parse_engine_telemetry(log)
        self.assertEqual(result["route"], "Ожидание трафика Telegram")

    def test_counter_delta_confirms_tcp_fallback(self):
        log = (
            "stats: total=2 active=0 ws=0 h2=0 tcp_fb=0 cf=0 up=0 B down=0 B\n"
            "stats: total=3 active=1 ws=0 h2=0 tcp_fb=1 cf=0 up=10 KB down=20 KB\n"
        )
        result = parse_engine_telemetry(log)
        self.assertEqual(result["route"], "Direct TCP fallback")
        self.assertEqual(result["up"], "10 KB")

    def test_engine_logs_redact_local_secret(self):
        secret = "0123456789abcdef0123456789abcdef"
        line = f"Secret: {secret}; tg://proxy?server=127.0.0.1&secret=dd{secret}\n"
        safe = _redact_line(line, secret)
        self.assertNotIn(secret, safe)
        self.assertIn("[REDACTED]", safe)

    def test_find_free_port(self):
        port = find_free_port(25000, 10)
        self.assertGreaterEqual(port, 25000)
        self.assertLessEqual(port, 25010)

    def test_parse_actual_upstream_stats_and_route(self):
        log = """[127.0.0.1] DC2 -> WS pool hit
[ART] stats: total=9 active=1 ws=5 h2=2 h2_tcp=0 h2_req=3 h2_err=1 tcp_fb=1 cf=2 front=0 bad=0 masked=0 err=0 pool=4/5 cf_pool=n/a up=12.1 MB down=45.4 MB
"""
        result = parse_engine_telemetry(log)
        self.assertEqual(result["route"], "WebSocket pool")
        self.assertEqual(result["ws"], "5")
        self.assertEqual(result["h2_errors"], "1")
        self.assertEqual(result["tcp"], "1")
        self.assertEqual(result["down"], "45.4 MB")


if __name__ == "__main__":
    unittest.main()
