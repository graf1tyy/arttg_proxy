import unittest

from art.catalog import merge_candidates, parse_proxy_link, _record_candidate, rank_candidates, _parse_feed, is_probeable_public_ip, select_probe_batch


class CatalogTests(unittest.TestCase):
    def test_parse_valid_tg_proxy_link(self):
        item = parse_proxy_link("tg://proxy?server=149.154.167.50&port=443&secret=0123456789abcdef0123456789abcdef", "test")
        self.assertIsNotNone(item)
        self.assertEqual(item.server, "149.154.167.50")
        self.assertEqual(item.port, 443)
        self.assertIn("test", item.sources)

    def test_reject_malformed_secret(self):
        self.assertIsNone(parse_proxy_link("tg://proxy?server=149.154.167.50&port=443&secret=xyz"))

    def test_reject_non_public_ip(self):
        self.assertIsNone(parse_proxy_link("tg://proxy?server=127.0.0.1&port=443&secret=0123456789abcdef0123456789abcdef"))
        self.assertIsNone(parse_proxy_link("tg://proxy?server=192.168.1.5&port=443&secret=0123456789abcdef0123456789abcdef"))

    def test_probe_budget_eligibility_accepts_only_literal_global_ips(self):
        self.assertTrue(is_probeable_public_ip("149.154.167.50"))
        self.assertFalse(is_probeable_public_ip("proxy.example.org"))
        self.assertFalse(is_probeable_public_ip("10.0.0.1"))
        self.assertFalse(is_probeable_public_ip("::1"))

    def test_probe_batch_skips_hostnames_without_spending_limit(self):
        items = [
            parse_proxy_link(f"tg://proxy?server=node{i}.example.org&port=443&secret=0123456789abcdef0123456789abcdef")
            for i in range(30)
        ]
        ip_item = parse_proxy_link("tg://proxy?server=149.154.167.50&port=443&secret=0123456789abcdef0123456789abcdef")
        batch = select_probe_batch([*items, ip_item], limit=1)
        self.assertEqual(batch, [ip_item])

    def test_probe_batch_limit_is_bounded(self):
        self.assertEqual(select_probe_batch([], limit=24), [])
        self.assertEqual(select_probe_batch([], limit=-1), [])

    def test_json_metadata_and_sponsor_status(self):
        candidate = _record_candidate({
            "server": "149.154.167.50", "port": 443,
            "secret": "0123456789abcdef0123456789abcdef",
            "verified": True, "success_rate": 0.99,
            "median_rtt_ms": 88, "ads": {"status": "present"},
        }, "iwizard")
        self.assertIsNotNone(candidate)
        self.assertTrue(candidate.verified)
        self.assertEqual(candidate.ads_status, "present")
        self.assertAlmostEqual(candidate.success_rate, 0.99)
        self.assertEqual(candidate.remote_rtt_ms, 88)

    def test_merge_prefers_known_sponsor_positive(self):
        a = parse_proxy_link("tg://proxy?server=149.154.167.50&port=443&secret=0123456789abcdef0123456789abcdef", "a")
        b = parse_proxy_link("tg://proxy?server=149.154.167.50&port=443&secret=0123456789abcdef0123456789abcdef", "b")
        a.ads_status = "none"
        b.ads_status = "present"
        merged = merge_candidates([[a], [b]])
        self.assertEqual(len(merged), 1)
        self.assertEqual(merged[0].ads_status, "present")
        self.assertEqual(merged[0].sources, {"a", "b"})


    def test_checked_plain_text_feeds_mark_upstream_verification(self):
        raw = b"tg://proxy?server=149.154.167.50&port=443&secret=0123456789abcdef0123456789abcdef\n"
        candidates, _ = _parse_feed("iwizard-best", "https://example.invalid/best.txt", raw)
        self.assertEqual(len(candidates), 1)
        self.assertTrue(candidates[0].verified)

    def test_percent_success_rate_is_normalised(self):
        candidate = _record_candidate({
            "server": "149.154.167.50", "port": 443,
            "secret": "0123456789abcdef0123456789abcdef",
            "success_rate": "98.5%",
        }, "test")
        self.assertAlmostEqual(candidate.success_rate, .985)

    def test_unknown_ad_status_is_not_auto_eligible(self):
        item = parse_proxy_link("tg://proxy?server=149.154.167.50&port=443&secret=0123456789abcdef0123456789abcdef")
        item.verified = True
        item.local_reachable = True
        item.success_rate = 0.99
        self.assertFalse(item.eligible_for_auto)

    def test_auto_eligible_requires_all_positive_evidence(self):
        item = parse_proxy_link("tg://proxy?server=149.154.167.50&port=443&secret=0123456789abcdef0123456789abcdef")
        item.verified = True
        item.ads_status = "none"
        item.local_reachable = True
        item.success_rate = 0.96
        self.assertTrue(item.eligible_for_auto)


if __name__ == "__main__":
    unittest.main()
