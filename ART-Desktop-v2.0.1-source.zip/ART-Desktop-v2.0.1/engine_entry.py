"""Headless entry point for Flowseal's documented console proxy engine."""
from __future__ import annotations

import json
import os
import sys

from proxy.tg_ws_proxy import main

if __name__ == "__main__":
    # ART sends this once over stdin. The secret is not exposed in the OS
    # process command line or environment variables.
    raw_args = sys.stdin.read()
    try:
        args = json.loads(raw_args)
        if not isinstance(args, list) or not all(isinstance(a, str) for a in args):
            raise ValueError("ART engine configuration must be a JSON list of strings")
    except Exception as exc:
        raise SystemExit(f"Invalid ART engine configuration: {exc}")
    try:
        sys.stdin.close()
    except Exception:
        pass
    sys.argv = [sys.argv[0], *args]
    main()
