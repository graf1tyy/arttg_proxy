from __future__ import annotations

import concurrent.futures
import json
import os
import re
import subprocess
import sys
import time
import urllib.parse
from pathlib import Path

from PySide6.QtCore import Qt, QThread, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QFont, QIcon, QMouseEvent, QTextCursor
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QFrame, QGridLayout, QHBoxLayout, QHeaderView,
    QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton, QSpinBox,
    QStackedWidget, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout,
    QWidget, QButtonGroup, QAbstractItemView, QSizeGrip,
)

from . import __version__
from .catalog import ProxyCandidate, open_proxy_link, probe_tcp, refresh_catalog, select_probe_batch
from .config import AppConfig, app_data_dir, load_config, save_config
from .engine import engine_path, find_free_port, is_local_listener, parse_engine_telemetry, proxy_uri, start_engine
from .history import apply_history, record_feedback


DARK_QSS = r"""
* { font-family: 'Segoe UI'; }
QMainWindow, QWidget#root { background: #0b0c0f; color: #f2f3f5; }
QFrame#titlebar { background: #0e1014; border-bottom: 1px solid #242832; }
QLabel#brand { color: #ffffff; font-size: 19px; font-weight: 800; letter-spacing: 1px; }
QLabel#muted { color: #8c929f; }
QLabel#section { color: #f3f4f6; font-size: 25px; font-weight: 700; }
QLabel#subsection { color: #9299a6; font-size: 12px; }
QFrame#sidebar { background: #0e1014; border-right: 1px solid #242832; }
QPushButton#nav { background: transparent; color: #9da3ae; border: 0; text-align: left; padding: 12px 14px; border-radius: 9px; font-size: 13px; }
QPushButton#nav:hover { background: #191c23; color: #ffffff; }
QPushButton#nav:checked { background: #20242d; color: #ffffff; font-weight: 700; }
QFrame#card { background: #12151b; border: 1px solid #252a35; border-radius: 15px; }
QFrame#hero { background: #12161d; border: 1px solid #2b3340; border-radius: 18px; }
QLabel#hero_title { font-size: 28px; font-weight: 750; color: #f8f9fb; }
QLabel#hero_desc { color: #a3aab7; font-size: 13px; }
QLabel#big_value { color: #ffffff; font-size: 21px; font-weight: 700; }
QLabel#card_title { color: #f0f2f5; font-size: 14px; font-weight: 700; }
QLabel#small { color: #8f97a5; font-size: 11px; }
QLabel#good { color: #83d6a5; font-weight: 700; }
QLabel#warn { color: #f4c879; font-weight: 700; }
QLabel#bad { color: #ff8585; font-weight: 700; }
QPushButton#primary { background: #f4f5f7; color: #111318; border: 0; border-radius: 10px; padding: 13px 22px; font-weight: 750; font-size: 13px; }
QPushButton#primary:hover { background: #dce0e6; }
QPushButton#primary:disabled { background: #444952; color: #9198a4; }
QPushButton#secondary { background: #222731; color: #ecedf0; border: 1px solid #333a47; border-radius: 9px; padding: 10px 15px; font-weight: 650; }
QPushButton#secondary:hover { background: #2a303b; }
QPushButton#danger { background: #351e22; color: #ffb4b4; border: 1px solid #5d3037; border-radius: 9px; padding: 10px 15px; font-weight: 700; }
QLineEdit, QSpinBox { background: #0d1015; color: #f2f3f5; border: 1px solid #303744; border-radius: 8px; padding: 9px; selection-background-color: #586477; }
QCheckBox { color: #d6d9df; spacing: 8px; }
QCheckBox::indicator { width: 17px; height: 17px; }
QCheckBox::indicator:unchecked { background: #171b22; border: 1px solid #4a5260; border-radius: 4px; }
QCheckBox::indicator:checked { background: #e8ebef; border: 1px solid #e8ebef; border-radius: 4px; }
QTableWidget { background: #11141a; color: #e8ebef; border: 1px solid #252a35; border-radius: 10px; gridline-color: #242a34; selection-background-color: #29313d; selection-color: #ffffff; }
QHeaderView::section { background: #171b22; color: #9ba3b0; border: 0; padding: 9px 7px; font-size: 11px; font-weight: 700; }
QTableWidget::item { padding: 7px; border-bottom: 1px solid #20252e; }
QTextEdit { background: #0d1015; color: #b7c0cd; border: 1px solid #2a303b; border-radius: 10px; font-family: Consolas; font-size: 11px; }
QLabel#pill { background: #20252e; color: #b8c0cd; border: 1px solid #353d4a; border-radius: 10px; padding: 5px 10px; font-size: 11px; font-weight: 700; }
QLabel#pill_good { background: #14271d; color: #89e0aa; border: 1px solid #27553a; border-radius: 10px; padding: 5px 10px; font-size: 11px; font-weight: 700; }
QLabel#pill_warn { background: #2b2416; color: #eac77e; border: 1px solid #5b4722; border-radius: 10px; padding: 5px 10px; font-size: 11px; font-weight: 700; }
QLabel#pill_bad { background: #2b191b; color: #ff9d9d; border: 1px solid #603236; border-radius: 10px; padding: 5px 10px; font-size: 11px; font-weight: 700; }
"""


class CatalogWorker(QThread):
    completed = Signal(object, object)
    status = Signal(str)

    def run(self) -> None:
        try:
            self.status.emit("Загружаю и объединяю источники…")
            candidates, errors = refresh_catalog(lambda name, count, err: self.status.emit(f"{name}: {count} записей" if not err else f"{name}: источник недоступен"))
            apply_history(candidates)
            candidates.sort(key=lambda p: (p.eligible_for_auto, *p.rank_tuple()), reverse=True)
            self.status.emit(f"Получено {len(candidates)} уникальных адресов. Проверяю доступность с этого компьютера…")
            # Bounded local TCP prefilter. This is not described as a full MTProto test.
            # Probe the top-ranked literal public IP candidates, not the first
            # 24 rows blindly: hostnames are intentionally skipped to avoid
            # unbounded resolver stalls, so they must not consume the probe budget.
            to_probe = select_probe_batch(candidates, limit=24)
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
                list(pool.map(probe_tcp, to_probe))
            candidates.sort(key=lambda p: (p.eligible_for_auto, *p.rank_tuple()), reverse=True)
            self.completed.emit(candidates, errors)
        except Exception as exc:
            self.completed.emit([], {"catalog": f"{type(exc).__name__}: {exc}"})


def card() -> QFrame:
    frame = QFrame()
    frame.setObjectName("card")
    return frame



def named(widget_type, name: str, *args):
    """Create a Qt widget and set its object name without constructor kwargs."""
    widget = widget_type(*args)
    widget.setObjectName(name)
    return widget


def title(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("section")
    return label


def small(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("small")
    return label


def mask_secrets(line: str) -> str:
    line = re.sub(r"(?i)(secret[\"']?\s*[:=]\s*[\"']?)(?:dd|ee)?[0-9a-f]{32,256}", r"\1[HIDDEN]", line)
    line = re.sub(r"(?i)(secret=)(?:dd|ee)?[0-9a-f]{32,256}", r"\1[HIDDEN]", line)
    return line


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("ART")
        self.setWindowFlags(Qt.Window | Qt.FramelessWindowHint)
        self.setMinimumSize(970, 650)
        self.resize(1120, 740)
        icon = Path(__file__).resolve().parent.parent / "assets" / "art.ico"
        if icon.exists():
            self.setWindowIcon(QIcon(str(icon)))
        self.config = load_config()
        self.engine_process: subprocess.Popen | None = None
        self.catalog: list[ProxyCandidate] = []
        self.catalog_errors: dict[str, str] = {}
        self.worker: CatalogWorker | None = None
        self.engine_started_at: float | None = None
        self.waiting_for_engine = False
        self.auto_open_pending = False
        self._telemetry_ticks = 0
        self._drag_pos = None
        self._listener_open = False
        self._last_listener_check = 0.0
        self._build_ui()
        self._apply_state(False, "Не подключено", "Локальный мост остановлен")
        self.timer = QTimer(self)
        self.timer.setInterval(1600)
        self.timer.timeout.connect(self._poll_engine)
        self.timer.start()
        self.catalog_timer = QTimer(self)
        self.catalog_timer.setInterval(self.config.auto_refresh_minutes * 60 * 1000)
        self.catalog_timer.timeout.connect(self.refresh_catalog)
        self.catalog_timer.start()
        QTimer.singleShot(900, self.refresh_catalog)

    def _build_ui(self) -> None:
        self.setStyleSheet(DARK_QSS)
        central = named(QWidget, "root")
        outer = QVBoxLayout(central)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        titlebar = named(QFrame, "titlebar")
        titlebar.setFixedHeight(48)
        top = QHBoxLayout(titlebar)
        top.setContentsMargins(18, 0, 12, 0)
        brand = named(QLabel, "brand", "art.")
        top.addWidget(brand)
        top.addSpacing(12)
        top.addWidget(named(QLabel, "muted", "TELEGRAM ROUTE MANAGER"))
        top.addStretch(1)
        self.global_status = named(QLabel, "pill", "● ОФЛАЙН")
        top.addWidget(self.global_status)
        top.addSpacing(12)
        min_btn = QPushButton("—")
        min_btn.setFixedSize(30, 28)
        min_btn.setObjectName("secondary")
        min_btn.clicked.connect(self.showMinimized)
        self.max_btn = QPushButton("□")
        self.max_btn.setFixedSize(30, 28)
        self.max_btn.setObjectName("secondary")
        self.max_btn.clicked.connect(self._toggle_maximize)
        close_btn = QPushButton("×")
        close_btn.setFixedSize(30, 28)
        close_btn.setObjectName("secondary")
        close_btn.clicked.connect(self.close)
        top.addWidget(min_btn)
        top.addWidget(self.max_btn)
        top.addWidget(close_btn)
        titlebar.mousePressEvent = self._title_press
        titlebar.mouseMoveEvent = self._title_move
        titlebar.mouseDoubleClickEvent = self._title_double_click
        outer.addWidget(titlebar)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        sidebar = named(QFrame, "sidebar")
        sidebar.setFixedWidth(206)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(14, 20, 14, 16)
        side.setSpacing(8)
        badge = named(QLabel, "brand", "ART")
        side.addWidget(badge)
        side.addWidget(small("УПРАВЛЕНИЕ МАРШРУТОМ"))
        side.addSpacing(25)
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.stack = QStackedWidget()
        pages = [("Главная", 0), ("Прокси", 1), ("Настройки", 2), ("Диагностика", 3)]
        for text, index in pages:
            btn = QPushButton(text)
            btn.setObjectName("nav")
            btn.setCheckable(True)
            btn.clicked.connect(lambda checked=False, i=index: self.stack.setCurrentIndex(i))
            self.nav_group.addButton(btn, index)
            side.addWidget(btn)
            if index == 0:
                btn.setChecked(True)
        side.addStretch(1)
        side.addWidget(named(QLabel, "small", "ART DESKTOP 2.0.1"))
        side.addWidget(named(QLabel, "small", "Transport core: Flowseal"))
        body.addWidget(sidebar)

        content_wrap = QWidget()
        content = QVBoxLayout(content_wrap)
        content.setContentsMargins(28, 24, 28, 20)
        content.setSpacing(18)
        self.stack.addWidget(self._dashboard_page())
        self.stack.addWidget(self._servers_page())
        self.stack.addWidget(self._settings_page())
        self.stack.addWidget(self._diagnostics_page())
        content.addWidget(self.stack)
        body.addWidget(content_wrap, 1)
        outer.addLayout(body, 1)
        grip_row = QHBoxLayout()
        grip_row.setContentsMargins(0, 0, 3, 2)
        grip_row.addStretch(1)
        grip_row.addWidget(QSizeGrip(central))
        outer.addLayout(grip_row)
        self.setCentralWidget(central)
        self.nav_group.idClicked.connect(self.stack.setCurrentIndex)

    def _dashboard_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)
        header = QVBoxLayout()
        header.addWidget(title("Подключение к Telegram"))
        header.addWidget(named(QLabel, "subsection", "ART сам управляет локальным транспортом и помогает выбрать резервный маршрут."))
        layout.addLayout(header)

        hero = named(QFrame, "hero")
        hero_layout = QHBoxLayout(hero)
        hero_layout.setContentsMargins(24, 24, 24, 24)
        left = QVBoxLayout()
        self.hero_state = named(QLabel, "hero_title", "Не подключено")
        self.hero_desc = named(QLabel, "hero_desc", "Запусти защищённый локальный мост. Telegram подключится к нему через MTProto.")
        self.hero_desc.setWordWrap(True)
        self.engine_badge = named(QLabel, "pill", "● ОСТАНОВЛЕН")
        self.connect_btn = named(QPushButton, "primary", "Подключить Telegram")
        self.connect_btn.setMinimumWidth(210)
        self.connect_btn.clicked.connect(self._on_connect_clicked)
        self.stop_btn = named(QPushButton, "danger", "Остановить")
        self.stop_btn.clicked.connect(self.stop_engine)
        self.stop_btn.setVisible(False)
        actions = QHBoxLayout()
        actions.addWidget(self.connect_btn)
        actions.addWidget(self.stop_btn)
        left.addWidget(self.engine_badge, alignment=Qt.AlignLeft)
        left.addSpacing(6)
        left.addWidget(self.hero_state)
        left.addWidget(self.hero_desc)
        left.addSpacing(18)
        left.addLayout(actions)
        hero_layout.addLayout(left, 1)
        right = QVBoxLayout()
        self.local_port = named(QLabel, "big_value", "127.0.0.1:1443")
        self.local_port_caption = named(QLabel, "small", "Локальный адрес")
        self.route_value = named(QLabel, "small", "Маршрут: не активен")
        self.route_value.setAlignment(Qt.AlignRight)
        right.addStretch(1)
        right.addWidget(self.local_port, alignment=Qt.AlignRight)
        right.addWidget(self.local_port_caption, alignment=Qt.AlignRight)
        right.addWidget(self.route_value)
        right.addStretch(1)
        hero_layout.addLayout(right)
        layout.addWidget(hero)

        stats = QGridLayout()
        stats.setHorizontalSpacing(12)
        stats.setVerticalSpacing(12)
        self.stat_engine = self._stat_card("Транспортное ядро", "Не запущено", "WS · CF · TCP fallback")
        self.stat_media = self._stat_card("Медиа-канал", "HTTP/2 включён", "Отдельный путь для медиа")
        self.stat_proxy = self._stat_card("Трафик через ART", "Ожидание", "Статистика движка появится после активности")
        stats.addWidget(self.stat_engine, 0, 0)
        stats.addWidget(self.stat_media, 0, 1)
        stats.addWidget(self.stat_proxy, 0, 2)
        layout.addLayout(stats)

        note = named(QFrame, "card")
        note_layout = QVBoxLayout(note)
        note_layout.setContentsMargins(18, 16, 18, 16)
        note_layout.addWidget(named(QLabel, "card_title", "Важно"))
        note_layout.addWidget(named(QLabel, "subsection", "ART подтверждает работу локального моста. Фактическое подключение Telegram и скорость видео проверяются самим клиентом при загрузке содержимого; один ping или открытый TCP-порт этого не доказывает."))
        layout.addWidget(note)
        layout.addStretch(1)
        return page

    def _stat_card(self, heading: str, value: str, desc: str) -> QFrame:
        frame = card()
        v = QVBoxLayout(frame)
        v.setContentsMargins(16, 14, 16, 14)
        v.addWidget(named(QLabel, "small", heading))
        value_label = named(QLabel, "big_value", value)
        value_label.setWordWrap(True)
        v.addWidget(value_label)
        v.addWidget(named(QLabel, "small", desc))
        frame.value_label = value_label
        return frame

    def _servers_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)
        layout.addWidget(title("Резервные прокси"))
        layout.addWidget(named(QLabel, "subsection", "Публичные MTProto-списки — запасной вариант, а не часть WS-движка. Короткая TCP-проверка открывает соединение к первым 24 публичным IP-адресам с твоей сети; она проверяет только порт, не содержимое Telegram."))
        bar = QHBoxLayout()
        self.catalog_status = named(QLabel, "muted", "Источники ещё не загружались")
        bar.addWidget(self.catalog_status, 1)
        self.best_proxy_btn = named(QPushButton, "secondary", "Открыть лучший кандидат")
        self.best_proxy_btn.clicked.connect(self._open_best_proxy)
        self.best_proxy_btn.setEnabled(False)
        bar.addWidget(self.best_proxy_btn)
        self.refresh_btn = named(QPushButton, "secondary", "Обновить список")
        self.refresh_btn.clicked.connect(self.refresh_catalog)
        bar.addWidget(self.refresh_btn)
        layout.addLayout(bar)
        summary = named(QFrame, "card")
        s = QHBoxLayout(summary)
        s.setContentsMargins(16, 12, 16, 12)
        self.catalog_total = named(QLabel, "big_value", "0")
        self.catalog_clean = named(QLabel, "big_value", "0")
        self.catalog_unknown = named(QLabel, "big_value", "0")
        for caption, widget in (("Найдено", self.catalog_total), ("Известно без рекламы", self.catalog_clean), ("Реклама неизвестна", self.catalog_unknown)):
            col = QVBoxLayout()
            col.addWidget(widget)
            col.addWidget(named(QLabel, "small", caption))
            s.addLayout(col)
            s.addStretch(1)
        layout.addWidget(summary)
        self.proxy_table = QTableWidget(0, 7)
        self.proxy_table.setHorizontalHeaderLabels(["Сервер", "Проверка источником", "Реклама", "TCP с ПК", "Моя оценка", "Источники", "Удалённый RTT"])
        self.proxy_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        for col in range(1, 7):
            self.proxy_table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeToContents)
        self.proxy_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.proxy_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.proxy_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.proxy_table.verticalHeader().setVisible(False)
        self.proxy_table.setAlternatingRowColors(False)
        self.proxy_table.itemSelectionChanged.connect(self._update_use_button)
        layout.addWidget(self.proxy_table, 1)
        footer = QHBoxLayout()
        self.use_proxy_btn = named(QPushButton, "secondary", "Открыть выбранный прокси в Telegram")
        self.use_proxy_btn.clicked.connect(self._use_selected_proxy)
        self.use_proxy_btn.setEnabled(False)
        footer.addWidget(self.use_proxy_btn)
        self.good_proxy_btn = named(QPushButton, "secondary", "У меня работает хорошо")
        self.good_proxy_btn.clicked.connect(self._mark_selected_good)
        self.good_proxy_btn.setEnabled(False)
        footer.addWidget(self.good_proxy_btn)
        self.bad_proxy_btn = named(QPushButton, "secondary", "Не работает / реклама")
        self.bad_proxy_btn.clicked.connect(self._mark_selected_bad)
        self.bad_proxy_btn.setEnabled(False)
        footer.addWidget(self.bad_proxy_btn)
        footer.addStretch(1)
        footer.addWidget(named(QLabel, "small", "TCP-проверка — только доступность порта, не тест MTProto."))
        layout.addLayout(footer)
        return page

    def _settings_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(14)
        layout.addWidget(title("Настройки ART"))
        layout.addWidget(named(QLabel, "subsection", "Сначала безопасные значения по умолчанию. Неизвестные Worker-домены не добавляются автоматически."))
        network = card()
        n = QVBoxLayout(network)
        n.setContentsMargins(18, 18, 18, 18)
        n.addWidget(named(QLabel, "card_title", "Локальный транспорт"))
        row = QHBoxLayout()
        row.addWidget(QLabel("Порт на этом компьютере"))
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1024, 65535)
        self.port_spin.setValue(self.config.port)
        row.addWidget(self.port_spin)
        row.addStretch(1)
        n.addLayout(row)
        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Размер пула WebSocket-соединений"))
        self.pool_spin = QSpinBox()
        self.pool_spin.setRange(0, 32)
        self.pool_spin.setValue(self.config.pool_size)
        row2.addWidget(self.pool_spin)
        row2.addStretch(1)
        n.addLayout(row2)
        row3 = QHBoxLayout()
        row3.addWidget(QLabel("Буфер, КБ"))
        self.buffer_spin = QSpinBox()
        self.buffer_spin.setRange(16, 8192)
        self.buffer_spin.setSingleStep(64)
        self.buffer_spin.setValue(self.config.buffer_kb)
        row3.addWidget(self.buffer_spin)
        row3.addStretch(1)
        n.addLayout(row3)
        row4 = QHBoxLayout()
        row4.addWidget(QLabel("Обновлять каталог прокси каждые, минут"))
        self.refresh_spin = QSpinBox()
        self.refresh_spin.setRange(15, 1440)
        self.refresh_spin.setSingleStep(15)
        self.refresh_spin.setValue(self.config.auto_refresh_minutes)
        row4.addWidget(self.refresh_spin)
        row4.addStretch(1)
        n.addLayout(row4)
        self.cf_check = QCheckBox("Разрешить Cloudflare fallback")
        self.cf_check.setChecked(self.config.cloudflare_enabled)
        self.h2_check = QCheckBox("Использовать HTTP/2 для медиа через CF")
        self.h2_check.setChecked(self.config.media_h2_enabled)
        self.auto_open_check = QCheckBox("Открывать ссылку подключения Telegram после запуска моста")
        self.auto_open_check.setChecked(self.config.auto_open_telegram)
        n.addWidget(self.cf_check)
        n.addWidget(self.h2_check)
        n.addWidget(self.auto_open_check)
        n.addWidget(named(QLabel, "small", "Свой CF-proxy домен (необязательно, через запятую)"))
        self.cf_domains_edit = QLineEdit(", ".join(self.config.cloudflare_domains))
        self.cf_domains_edit.setPlaceholderText("my-domain.example")
        n.addWidget(self.cf_domains_edit)
        n.addWidget(named(QLabel, "small", "Cloudflare Worker domains (необязательно, через запятую)"))
        self.worker_domains_edit = QLineEdit(", ".join(self.config.worker_domains))
        self.worker_domains_edit.setPlaceholderText("example.workers.dev")
        n.addWidget(self.worker_domains_edit)
        layout.addWidget(network)
        security = card()
        sec = QVBoxLayout(security)
        sec.setContentsMargins(18, 16, 18, 16)
        sec.addWidget(named(QLabel, "card_title", "Безопасность"))
        sec.addWidget(named(QLabel, "subsection", "Локальный listener всегда привязан к 127.0.0.1. Секрет генерируется случайно и не показывается в логах. Публичные proxy-серверы являются сторонними узлами."))
        layout.addWidget(security)
        actions = QHBoxLayout()
        save_btn = named(QPushButton, "primary", "Сохранить настройки")
        save_btn.clicked.connect(self.save_settings)
        actions.addWidget(save_btn)
        restart_btn = named(QPushButton, "secondary", "Применить и перезапустить")
        restart_btn.clicked.connect(self.apply_and_restart)
        actions.addWidget(restart_btn)
        actions.addStretch(1)
        layout.addLayout(actions)
        layout.addStretch(1)
        return page

    def _diagnostics_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)
        layout.addWidget(title("Диагностика"))
        layout.addWidget(named(QLabel, "subsection", "Здесь разделены состояние процесса, локального порта и сетевые симптомы. TCP-проверки не считаются подтверждением работоспособности Telegram."))
        row = QHBoxLayout()
        self.diag_engine = named(QLabel, "card_title", "Ядро: не запущено")
        self.diag_listener = named(QLabel, "card_title", "Локальный порт: закрыт")
        row.addWidget(self.diag_engine)
        row.addStretch(1)
        row.addWidget(self.diag_listener)
        layout.addLayout(row)
        buttons = QHBoxLayout()
        check_btn = named(QPushButton, "secondary", "Проверить локальный мост")
        check_btn.clicked.connect(self.run_diagnostics)
        buttons.addWidget(check_btn)
        open_log = named(QPushButton, "secondary", "Открыть журнал")
        open_log.clicked.connect(self.open_log)
        buttons.addWidget(open_log)
        buttons.addStretch(1)
        layout.addLayout(buttons)
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setPlaceholderText("Журнал появится после первого запуска…")
        layout.addWidget(self.log_view, 1)
        return page

    def _toggle_maximize(self) -> None:
        if self.isMaximized():
            self.showNormal()
            self.max_btn.setText("□")
        else:
            self.showMaximized()
            self.max_btn.setText("❐")

    def _title_double_click(self, event: QMouseEvent) -> None:
        if event.button() == Qt.LeftButton:
            self._toggle_maximize()

    def _title_press(self, event: QMouseEvent) -> None:
        if event.button() == Qt.LeftButton and not self.isMaximized():
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def _title_move(self, event: QMouseEvent) -> None:
        if self._drag_pos is not None and event.buttons() & Qt.LeftButton and not self.isMaximized():
            self.move(event.globalPosition().toPoint() - self._drag_pos)

    def _apply_state(self, online: bool, headline: str, detail: str) -> None:
        if online:
            self.global_status.setText("● МОСТ АКТИВЕН")
            self.global_status.setObjectName("pill_good")
            self.engine_badge.setText("● РАБОТАЕТ")
            self.engine_badge.setObjectName("pill_good")
            self.hero_state.setText("Локальный мост активен")
            self.connect_btn.setText("Открыть Telegram")
            self.stop_btn.setVisible(True)
            self.stat_engine.value_label.setText("Запущено")
        else:
            self.global_status.setText("● ОФЛАЙН")
            self.global_status.setObjectName("pill")
            self.engine_badge.setText("● ОСТАНОВЛЕН")
            self.engine_badge.setObjectName("pill")
            self.hero_state.setText(headline)
            self.connect_btn.setText("Подключить Telegram")
            self.stop_btn.setVisible(False)
            self.stat_engine.value_label.setText("Не запущено")
            self.route_value.setText("Маршрут: не активен")
        self.hero_desc.setText(detail)
        self.global_status.style().unpolish(self.global_status)
        self.global_status.style().polish(self.global_status)
        self.engine_badge.style().unpolish(self.engine_badge)
        self.engine_badge.style().polish(self.engine_badge)

    def _on_connect_clicked(self) -> None:
        if self.engine_process and self.engine_process.poll() is None and is_local_listener("127.0.0.1", self.config.port):
            self.open_telegram()
            return
        self.start_engine()

    def start_engine(self) -> None:
        if self.engine_process and self.engine_process.poll() is None:
            return
        path = engine_path()
        if not path.exists():
            QMessageBox.critical(self, "ART Engine отсутствует", "В комплекте не найден engine\\ART-Engine.exe. Эта сборка неполная или была распакована не целиком.")
            return
        if is_local_listener("127.0.0.1", self.config.port):
            self.config.port = find_free_port(self.config.port + 1)
            save_config(self.config)
            self.port_spin.setValue(self.config.port)
        self.waiting_for_engine = True
        self._listener_open = False
        self._last_listener_check = 0.0
        self.auto_open_pending = self.config.auto_open_telegram
        self.engine_started_at = time.time()
        self._apply_state(False, "Запускаю транспорт…", "ART запускает локальный движок в фоновом режиме и проверяет готовность порта.")
        self.connect_btn.setEnabled(False)
        try:
            self.engine_process = start_engine(self.config, app_data_dir() / "engine.log", path)
        except Exception as exc:
            self.waiting_for_engine = False
            self.connect_btn.setEnabled(True)
            QMessageBox.critical(self, "Не удалось запустить ART", str(exc))

    def _poll_engine(self) -> None:
        self._telemetry_ticks += 1
        alive = bool(self.engine_process and self.engine_process.poll() is None)
        now = time.monotonic()
        if not alive:
            self._listener_open = False
        elif self.waiting_for_engine or now - self._last_listener_check >= 8.0:
            self._listener_open = is_local_listener("127.0.0.1", self.config.port)
            self._last_listener_check = now
        listener = self._listener_open
        if alive and listener:
            if self.waiting_for_engine:
                self.waiting_for_engine = False
                self.connect_btn.setEnabled(True)
                self._apply_state(True, "Локальный мост активен", "Теперь добавь или включи локальный MTProto-прокси в Telegram. ART не выдаёт открытый порт за подтверждение реальной загрузки чатов/видео.")
                self.local_port.setText(f"127.0.0.1:{self.config.port}")
                self.stat_engine.value_label.setText("Работает")
                self.stat_media.value_label.setText("HTTP/2 включён" if self.config.media_h2_enabled else "HTTP/2 выключен")
                if self.auto_open_pending:
                    self.auto_open_pending = False
                    QTimer.singleShot(350, self.open_telegram)
                self.run_diagnostics()
        elif alive and self.waiting_for_engine:
            elapsed = time.time() - (self.engine_started_at or time.time())
            if elapsed > 25:
                self.waiting_for_engine = False
                self.connect_btn.setEnabled(True)
                self.stop_engine()
                QMessageBox.warning(self, "ART не запустился", "Ядро не открыло локальный порт за 25 секунд. Открой диагностику и проверь журнал — в нём должна быть причина.")
        elif self.engine_process and not alive:
            code = self.engine_process.returncode
            self.engine_process = None
            if self.waiting_for_engine:
                self.waiting_for_engine = False
                self.connect_btn.setEnabled(True)
                self._apply_state(False, "Движок завершился", f"ART Engine завершился с кодом {code}. Подробности находятся в журнале.")
                self.run_diagnostics()
            else:
                self._apply_state(False, "Соединение остановлено", "Транспортный процесс завершён.")
        self.diag_engine.setText("Ядро: запущено" if alive else "Ядро: не запущено")
        self.diag_listener.setText("Локальный порт: открыт" if listener else "Локальный порт: закрыт")
        if alive and self._telemetry_ticks % 8 == 0:
            self.run_diagnostics()

    def stop_engine(self) -> None:
        proc = self.engine_process
        self.engine_process = None
        self.waiting_for_engine = False
        self._listener_open = False
        if proc and proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=3.0)
            except subprocess.TimeoutExpired:
                proc.kill()
                try:
                    proc.wait(timeout=2.0)
                except subprocess.TimeoutExpired:
                    pass
            except OSError:
                pass
        self.connect_btn.setEnabled(True)
        self._apply_state(False, "Не подключено", "Локальный мост остановлен.")
        self.diag_engine.setText("Ядро: не запущено")
        self.diag_listener.setText("Локальный порт: закрыт")

    def open_telegram(self) -> None:
        uri = proxy_uri(self.config)
        ok = QDesktopServices.openUrl(QUrl(uri))
        if not ok:
            QApplication.clipboard().setText(uri)
            QMessageBox.information(self, "Ссылка скопирована", "Не удалось открыть обработчик Telegram. Ссылка локального прокси скопирована в буфер обмена; открой её в Telegram.")

    def save_settings(self) -> None:
        self.config.port = self.port_spin.value()
        self.config.pool_size = self.pool_spin.value()
        self.config.buffer_kb = self.buffer_spin.value()
        self.config.auto_refresh_minutes = self.refresh_spin.value()
        self.config.cloudflare_enabled = self.cf_check.isChecked()
        self.config.media_h2_enabled = self.h2_check.isChecked()
        self.config.auto_open_telegram = self.auto_open_check.isChecked()
        self.config.worker_domains = tuple(p.strip() for p in self.worker_domains_edit.text().split(",") if p.strip())
        self.config.cloudflare_domains = tuple(p.strip() for p in self.cf_domains_edit.text().split(",") if p.strip())
        self.config.normalise()
        save_config(self.config)
        self.local_port.setText(f"127.0.0.1:{self.config.port}")
        self.catalog_timer.setInterval(self.config.auto_refresh_minutes * 60 * 1000)
        QMessageBox.information(self, "Настройки сохранены", "Параметры сохранены. Для изменения работающего транспорта требуется перезапуск ART Engine.")

    def apply_and_restart(self) -> None:
        was_running = bool(self.engine_process and self.engine_process.poll() is None)
        self.save_settings()
        if was_running:
            self.stop_engine()
            QTimer.singleShot(500, self.start_engine)

    def refresh_catalog(self) -> None:
        if self.worker and self.worker.isRunning():
            return
        self.refresh_btn.setEnabled(False)
        self.catalog_status.setText("Обновляю источники…")
        self.worker = CatalogWorker(self)
        self.worker.status.connect(self.catalog_status.setText)
        self.worker.completed.connect(self._catalog_done)
        self.worker.start()

    def _catalog_done(self, candidates, errors) -> None:
        self.catalog = list(candidates)
        self.catalog_errors = dict(errors)
        self.refresh_btn.setEnabled(True)
        self.proxy_table.setRowCount(0)
        for candidate in self.catalog[:100]:
            row = self.proxy_table.rowCount()
            self.proxy_table.insertRow(row)
            self.proxy_table.setItem(row, 0, QTableWidgetItem(candidate.label))
            self.proxy_table.setItem(row, 1, QTableWidgetItem("Проверен источником" if candidate.verified else "Не подтверждён"))
            ads_text = {"none": "Нет по проверке", "present": "Есть реклама", "unknown": "Неизвестно"}.get(candidate.ads_status, "Неизвестно")
            self.proxy_table.setItem(row, 2, QTableWidgetItem(ads_text))
            tcp_text = f"{candidate.local_tcp_ms} ms" if candidate.local_reachable else ("Недоступен" if candidate.local_reachable is False else "Не проверен")
            self.proxy_table.setItem(row, 3, QTableWidgetItem(tcp_text))
            feedback_text = {"good": f"Хорошо ({candidate.user_good_count})", "bad": "Плохой", "ads": "Реклама"}.get(candidate.user_feedback, "Не оценён")
            self.proxy_table.setItem(row, 4, QTableWidgetItem(feedback_text))
            self.proxy_table.setItem(row, 5, QTableWidgetItem(", ".join(sorted(candidate.sources))[:50]))
            remote = f"{candidate.remote_rtt_ms:g} ms" if candidate.remote_rtt_ms is not None else "—"
            self.proxy_table.setItem(row, 6, QTableWidgetItem(remote))
            self.proxy_table.item(row, 0).setData(Qt.UserRole, row)
            if candidate.eligible_for_auto:
                self.proxy_table.item(row, 0).setToolTip("Подходит под строгие критерии: источник подтвердил MTProto, ads.status=none, TCP доступен с этого ПК.")
            else:
                self.proxy_table.item(row, 0).setToolTip("Не выбран автоматически. Требования к проверке MTProto и/или рекламе не подтверждены.")
        clean = sum(1 for p in self.catalog if p.ads_status == "none")
        unknown = sum(1 for p in self.catalog if p.ads_status == "unknown")
        eligible = sum(1 for p in self.catalog if p.eligible_for_auto)
        self.catalog_total.setText(str(len(self.catalog)))
        self.catalog_clean.setText(str(clean))
        self.catalog_unknown.setText(str(unknown))
        errors_text = f" · {len(errors)} источников с ошибкой" if errors else ""
        self.catalog_status.setText(f"Обновлено: найдено {len(self.catalog)} уникальных MTProto · {eligible} прошли строгий фильтр{errors_text}")
        self.best_proxy_btn.setEnabled(eligible > 0)
        self._update_use_button()

    def _open_best_proxy(self) -> None:
        candidate = next((item for item in self.catalog if item.eligible_for_auto), None)
        if candidate is None:
            QMessageBox.information(
                self, "Нет кандидата с достаточными подтверждениями",
                "Сейчас нет прокси, который одновременно проверен источником, доступен по TCP с этого компьютера и имеет подтверждённый статус без рекламы. ART не будет выдавать неизвестный статус за безопасный. Можно выбрать сервер вручную, но для него появится предупреждение.",
            )
            return
        answer = QMessageBox.question(
            self, "Лучший кандидат на текущий момент",
            f"{candidate.label}\n\nОн прошёл строгий предварительный фильтр. Это не гарантия загрузки Telegram или видео на твоём тарифе. Открыть его в Telegram?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes,
        )
        if answer == QMessageBox.Yes:
            QDesktopServices.openUrl(QUrl(open_proxy_link(candidate)))

    def _selected_candidate(self) -> ProxyCandidate | None:
        rows = self.proxy_table.selectionModel().selectedRows()
        if not rows:
            return None
        index = rows[0].row()
        return self.catalog[index] if 0 <= index < len(self.catalog) else None

    def _update_use_button(self) -> None:
        selected = self._selected_candidate()
        enabled = selected is not None
        self.use_proxy_btn.setEnabled(enabled)
        self.good_proxy_btn.setEnabled(enabled)
        self.bad_proxy_btn.setEnabled(enabled)

    def _mark_selected_good(self) -> None:
        candidate = self._selected_candidate()
        if not candidate:
            return
        answer = QMessageBox.question(
            self, "Подтвердить качество",
            "Ты уже подключал этот прокси в Telegram, проверил реальную работу (сообщения/фото/видео) и убедился, что не появляется рекламный/спонсорский канал?\n\nART запомнит скорость и отсутствие замеченной рекламы на этом компьютере и будет учитывать их при выборе.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        record_feedback(candidate, "good")
        self.catalog.sort(key=lambda p: (p.eligible_for_auto, *p.rank_tuple()), reverse=True)
        self._catalog_done(self.catalog, self.catalog_errors)

    def _mark_selected_bad(self) -> None:
        candidate = self._selected_candidate()
        if not candidate:
            return
        dialog = QMessageBox(self)
        dialog.setWindowTitle("Оценка прокси")
        dialog.setText("Что произошло с этим прокси?")
        bad_button = dialog.addButton("Не работает / очень медленный", QMessageBox.AcceptRole)
        ads_button = dialog.addButton("Появляется рекламный канал", QMessageBox.DestructiveRole)
        dialog.addButton("Отмена", QMessageBox.RejectRole)
        dialog.exec()
        clicked = dialog.clickedButton()
        if clicked == bad_button:
            record_feedback(candidate, "bad")
        elif clicked == ads_button:
            record_feedback(candidate, "ads")
        else:
            return
        self.catalog.sort(key=lambda p: (p.eligible_for_auto, *p.rank_tuple()), reverse=True)
        self._catalog_done(self.catalog, self.catalog_errors)

    def _use_selected_proxy(self) -> None:
        rows = self.proxy_table.selectionModel().selectedRows()
        if not rows:
            return
        idx = rows[0].row()
        if idx >= len(self.catalog):
            return
        candidate = self.catalog[idx]
        if candidate.ads_status == "present" or candidate.user_feedback == "ads":
            QMessageBox.warning(self, "Прокси с рекламой", "Источник или твоя предыдущая оценка подтвердили рекламный канал. ART не будет рекомендовать этот прокси.")
            return
        if candidate.ads_status == "unknown":
            answer = QMessageBox.question(self, "Реклама не проверена", "Нельзя подтвердить отсутствие рекламного канала. Продолжить и добавить этот сторонний прокси в Telegram?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if answer != QMessageBox.Yes:
                return
        QDesktopServices.openUrl(QUrl(open_proxy_link(candidate)))

    def run_diagnostics(self) -> None:
        listener = is_local_listener("127.0.0.1", self.config.port)
        alive = bool(self.engine_process and self.engine_process.poll() is None)
        self.diag_engine.setText("Ядро: запущено" if alive else "Ядро: не запущено")
        self.diag_listener.setText("Локальный порт: открыт" if listener else "Локальный порт: закрыт")
        log_path = app_data_dir() / "engine.log"
        try:
            lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-180:]
            safe = "\n".join(mask_secrets(line) for line in lines)
        except OSError:
            safe = "Журнал ещё не создан."
        self.log_view.setPlainText(safe)
        self.log_view.moveCursor(QTextCursor.End)
        telemetry = parse_engine_telemetry(safe)
        self.stat_engine.value_label.setText(f"WS {telemetry['ws']} · CF {telemetry['cf']} · TCP {telemetry['tcp']}")
        self.stat_media.value_label.setText(f"HTTP/2: {telemetry['h2']} · ошибки: {telemetry['h2_errors']}")
        self.stat_proxy.value_label.setText(f"↓ {telemetry['down']}  ↑ {telemetry['up']}")
        self.local_port.setToolTip(f"Последний транспортный маршрут по журналу: {telemetry['route']}")
        self.route_value.setText(f"Маршрут: {telemetry['route']}")

    def open_log(self) -> None:
        path = app_data_dir() / "engine.log"
        if path.exists():
            if sys.platform == "win32":
                os.startfile(str(path))
            else:
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        else:
            QMessageBox.information(self, "Журнал отсутствует", "Запусти транспортный движок — журнал будет создан автоматически.")

    def closeEvent(self, event) -> None:
        if self.worker and self.worker.isRunning():
            self.worker.requestInterruption()
            self.worker.wait(14000)
        self.stop_engine()
        event.accept()
