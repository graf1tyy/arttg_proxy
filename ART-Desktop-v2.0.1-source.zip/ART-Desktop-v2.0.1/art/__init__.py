"""ART desktop controller."""
__version__ = "2.0.1"
