from __future__ import annotations

import json
import os
import re
import socket
import subprocess
import sys
import threading
from pathlib import Path
from .config import AppConfig


def runtime_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def engine_path() -> Path:
    return runtime_root() / "engine" / ("ART-Engine.exe" if os.name == "nt" else "ART-Engine")


def build_engine_args(config: AppConfig, log_path: Path) -> list[str]:
    cfg = config.normalise()
    args = [
        "--host", "127.0.0.1",
        "--port", str(cfg.port),
        "--secret", cfg.secret,
        "--pool-size", str(cfg.pool_size),
        "--buf-kb", str(cfg.buffer_kb),
    ]
    if not cfg.cloudflare_enabled:
        args.append("--no-cfproxy")
    if not cfg.media_h2_enabled:
        args.append("--no-h2")
    for domain in cfg.cloudflare_domains:
        args.extend(["--cfproxy-domain", domain])
    for domain in cfg.worker_domains:
        args.extend(["--cfproxy-worker-domain", domain])
    return args


def make_engine_command(config: AppConfig, log_path: Path, executable: Path | None = None) -> list[str]:
    binary = executable or engine_path()
    if not binary.is_file():
        raise FileNotFoundError(
            "Не найден ART-Engine. Убедитесь, что папка engine находится рядом с ART.exe."
        )
    # No secret or runtime options are placed in the OS command line.
    return [str(binary)]


def _redact_line(line: str, secret: str = "") -> str:
    if secret:
        line = re.sub(re.escape(secret), "[REDACTED]", line, flags=re.IGNORECASE)
    line = re.sub(
        r"(?i)(secret(?:\s*[:=]\s*|=))(?:dd|ee)?[0-9a-f]{32,256}",
        r"\1[REDACTED]", line,
    )
    line = re.sub(
        r"(?i)(tg://proxy\?[^\s]*?secret=)(?:dd|ee)?[0-9a-f]{32,256}",
        r"\1[REDACTED]", line,
    )
    return line


def _pump_safe_log(proc: subprocess.Popen, log_path: Path, secret: str) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with log_path.open("a", encoding="utf-8", errors="replace") as sink:
            sink.write("\n--- ART Engine started ---\n")
            if proc.stdout is not None:
                for raw in proc.stdout:
                    sink.write(_redact_line(raw, secret))
                    sink.flush()
            sink.write("--- ART Engine output closed ---\n")
    except OSError:
        # Logging must never stop the proxy process.
        pass


def start_engine(config: AppConfig, log_path: Path, executable: Path | None = None) -> subprocess.Popen:
    command = make_engine_command(config, log_path, executable)
    binary = executable or engine_path()
    # Send runtime arguments over a one-shot private pipe. The MTProto secret
    # is therefore absent from both the OS command line and process environment.
    payload = json.dumps(build_engine_args(config, log_path))
    kwargs: dict = {
        "cwd": str(binary.parent),
        "stdin": subprocess.PIPE,
        "stdout": subprocess.PIPE,
        "stderr": subprocess.STDOUT,
        "close_fds": True,
        "bufsize": 1,
        "text": True,
        "encoding": "utf-8",
        "errors": "replace",
    }
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        startup = subprocess.STARTUPINFO()
        startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startup.wShowWindow = 0
        kwargs["startupinfo"] = startup
    proc = subprocess.Popen(command, **kwargs)
    try:
        assert proc.stdin is not None
        proc.stdin.write(payload)
        proc.stdin.close()
    except (BrokenPipeError, OSError):
        try:
            proc.terminate()
        except OSError:
            pass
        raise RuntimeError("ART Engine закрывает канал конфигурации до запуска.")
    reader = threading.Thread(
        target=_pump_safe_log, args=(proc, log_path, config.secret),
        name="ART-Engine-Log", daemon=True,
    )
    reader.start()
    proc._art_log_thread = reader  # keep a reference for orderly shutdown
    return proc


def is_local_listener(host: str, port: int, timeout: float = 0.35) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def find_free_port(preferred: int, attempts: int = 40) -> int:
    for port in range(preferred, min(65535, preferred + attempts) + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def proxy_uri(config: AppConfig) -> str:
    cfg = config.normalise()
    return f"tg://proxy?server=127.0.0.1&port={cfg.port}&secret=dd{cfg.secret}"


def parse_engine_telemetry(log_text: str) -> dict[str, str]:
    """Extract real upstream counters and the last positively observed route."""
    result = {
        "route": "Ожидание трафика Telegram",
        "ws": "0", "cf": "0", "tcp": "0", "h2": "0",
        "h2_errors": "0", "active": "0", "total": "0",
        "up": "—", "down": "—",
    }
    previous: dict[str, int] | None = None
    for line in log_text.splitlines():
        # These log messages confirm a selected/active transport, rather than
        # merely an attempted connection that may still fail.
        if "WS pool hit" in line:
            result["route"] = "WebSocket pool"
        elif "CF worker pool hit" in line:
            result["route"] = "Cloudflare Worker"
        elif "Switched active CF domain" in line:
            result["route"] = "Cloudflare proxy"

        if "stats:" not in line:
            continue
        patterns = {
            "total": r"\btotal=(\d+)",
            "active": r"\bactive=(\d+)",
            "ws": r"\bws=(\d+)",
            "h2": r"\bh2=(\d+)",
            "h2_errors": r"\bh2_err=(\d+)",
            "tcp": r"\btcp_fb=(\d+)",
            "cf": r"\bcf=(\d+)",
        }
        current: dict[str, int] = {}
        for key, pattern in patterns.items():
            match = re.search(pattern, line)
            if match:
                current[key] = int(match.group(1))
                result[key] = match.group(1)
        for key, pattern in {
            "up": r"\bup=([0-9.]+\s*(?:B|KB|MB|GB|TB|KiB|MiB|GiB|TiB))",
            "down": r"\bdown=([0-9.]+\s*(?:B|KB|MB|GB|TB|KiB|MiB|GiB|TiB))",
        }.items():
            match = re.search(pattern, line, re.IGNORECASE)
            if match:
                result[key] = match.group(1).strip()

        # Counters are cumulative. Their increase between periodic snapshots
        # confirms that a fallback path succeeded, avoiding false positives
        # from log lines that only say "trying" or "failed".
        if previous is not None:
            if current.get("h2", 0) > previous.get("h2", 0):
                result["route"] = "Cloudflare HTTP/2 (media)"
            elif current.get("tcp", 0) > previous.get("tcp", 0):
                result["route"] = "Direct TCP fallback"
            elif current.get("cf", 0) > previous.get("cf", 0):
                result["route"] = "Cloudflare fallback"
            elif current.get("ws", 0) > previous.get("ws", 0):
                result["route"] = "WebSocket pool"
        previous = current
    return result
