from __future__ import annotations

import hashlib
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import app_data_dir
from .catalog import ProxyCandidate


def _proxy_id(candidate: ProxyCandidate) -> str:
    raw = f"{candidate.server.lower().rstrip('.')}|{candidate.port}|{candidate.secret.lower()}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _safe_count(value: Any) -> int:
    """Read counters from hand-edited/corrupt history without crashing the UI."""
    try:
        count = int(value or 0)
    except (TypeError, ValueError, OverflowError):
        return 0
    return max(0, min(count, 1_000_000))


def _history_path() -> Path:
    return app_data_dir() / "proxy-history.json"


def load_history(path: Path | None = None) -> dict[str, dict[str, Any]]:
    target = path or _history_path()
    try:
        raw = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {}
    if not isinstance(raw, dict):
        return {}
    return {key: value for key, value in raw.items() if isinstance(key, str) and isinstance(value, dict)}


def save_history(data: dict[str, dict[str, Any]], path: Path | None = None) -> None:
    target = path or _history_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix="proxy-history-", suffix=".tmp", dir=target.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(data, stream, indent=2, ensure_ascii=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, target)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def apply_history(candidates: list[ProxyCandidate], data: dict[str, dict[str, Any]] | None = None) -> None:
    saved = data if data is not None else load_history()
    now = datetime.now(timezone.utc)
    for candidate in candidates:
        row = saved.get(_proxy_id(candidate), {})
        feedback = row.get("feedback", "")
        if feedback not in {"good", "bad", "ads"}:
            feedback = ""
        candidate.user_feedback = feedback
        candidate.user_good_count = _safe_count(row.get("good_count", 0))
        candidate.user_bad_count = _safe_count(row.get("bad_count", 0))

        reviewed_at = None
        try:
            reviewed_at = datetime.fromisoformat(str(row.get("updated_at", "")))
            if reviewed_at.tzinfo is None:
                reviewed_at = reviewed_at.replace(tzinfo=timezone.utc)
        except (TypeError, ValueError):
            pass
        review_age = (now - reviewed_at).total_seconds() if reviewed_at else None
        fresh_good = (
            feedback == "good" and review_age is not None
            and 0 <= review_age <= 72 * 60 * 60
        )
        candidate.user_review_fresh = fresh_good

        saved_ads = row.get("ads_status")
        # A current source-confirmed ad finding wins over an older local
        # positive review. A remembered sponsor report remains a hard warning.
        if candidate.ads_status != "present":
            if saved_ads == "present":
                candidate.ads_status = "present"
            elif saved_ads == "none" and (feedback != "good" or fresh_good):
                candidate.ads_status = "none"
            elif saved_ads == "unknown" and candidate.ads_status == "unknown":
                candidate.ads_status = "unknown"

        if feedback == "ads":
            candidate.ads_status = "present"
        elif fresh_good:
            # A recent real Telegram session is stronger evidence than a
            # remote RTT/TCP check. Older reviews still affect ranking but do
            # not make a public server permanently auto-eligible.
            candidate.verified = True
            candidate.local_reachable = True
            if candidate.ads_status != "present":
                candidate.ads_status = "none"


def record_feedback(candidate: ProxyCandidate, feedback: str, path: Path | None = None) -> None:
    if feedback not in {"good", "bad", "ads"}:
        raise ValueError("feedback must be 'good', 'bad', or 'ads'")
    target = path or _history_path()
    data = load_history(target)
    key = _proxy_id(candidate)
    row = data.get(key, {})
    good_count = _safe_count(row.get("good_count", 0))
    bad_count = _safe_count(row.get("bad_count", 0))
    if feedback == "good":
        good_count += 1
    else:
        bad_count += 1
    data[key] = {
        "server": candidate.server,
        "port": candidate.port,
        "feedback": feedback,
        "good_count": good_count,
        "bad_count": bad_count,
        # A positive review is only recorded after the UI asks the user to
        # confirm both useful performance and no observed sponsor/ad channel.
        "ads_status": (
            "present" if feedback == "ads" or candidate.ads_status == "present"
            else "none" if feedback == "good"
            else row.get("ads_status", candidate.ads_status)
        ),
        "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    save_history(data, target)
    candidate.user_feedback = feedback
    candidate.user_good_count = good_count
    candidate.user_bad_count = bad_count
    if feedback == "good":
        candidate.verified = True
        candidate.local_reachable = True
        candidate.user_review_fresh = True
        if candidate.ads_status != "present":
            candidate.ads_status = "none"
    elif feedback == "ads":
        candidate.user_review_fresh = False
        candidate.ads_status = "present"
    else:
        candidate.user_review_fresh = False
