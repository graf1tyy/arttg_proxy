from __future__ import annotations

import concurrent.futures
import ipaddress
import json
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Iterable

USER_AGENT = "ART-Desktop/2.0.1"
FEEDS = {
    "iwizard-best": "https://raw.githubusercontent.com/iwizard7/MTProxy_list/data/best.txt",
    "iwizard-stable": "https://raw.githubusercontent.com/iwizard7/MTProxy_list/data/stable.txt",
    "iwizard-endpoints": "https://raw.githubusercontent.com/iwizard7/MTProxy_list/data/endpoints.json",
    "radikal-top100": "https://raw.githubusercontent.com/0xRadikal/Free-Telegram-Proxy/main/top100.txt",
    "radikal-proxies": "https://raw.githubusercontent.com/0xRadikal/Free-Telegram-Proxy/main/resilient/proxies.json",
    "pink-mtproto": "https://raw.githubusercontent.com/tgproxypink/telegram-proxy-list/main/mtproto.txt",
    "pink-json": "https://raw.githubusercontent.com/tgproxypink/telegram-proxy-list/main/proxies.json",
}


@dataclass
class ProxyCandidate:
    server: str
    port: int
    secret: str
    scheme: str = "mtproto"
    sources: set[str] = field(default_factory=set)
    verified: bool = False
    success_rate: float | None = None
    uptime: float | None = None
    remote_rtt_ms: float | None = None
    ads_status: str = "unknown"
    last_checked: str | None = None
    local_tcp_ms: float | None = None
    local_reachable: bool | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    user_feedback: str = ""  # "good", "bad", or "ads"; recorded only after user confirmation
    user_good_count: int = 0
    user_bad_count: int = 0
    user_review_fresh: bool = False

    @property
    def key(self) -> tuple[str, int, str]:
        return (self.server.lower().rstrip("."), int(self.port), self.secret.lower())

    @property
    def label(self) -> str:
        return f"{self.server}:{self.port}"

    @property
    def eligible_for_auto(self) -> bool:
        return (
            self.verified
            and self.ads_status == "none"
            and self.local_reachable is True
            and self.user_feedback not in {"bad", "ads"}
            and (self.user_review_fresh or self.success_rate is None or self.success_rate >= 0.90)
        )

    def rank_tuple(self) -> tuple[float, ...]:
        # Public-runner metadata is a prior, not a promise about the user's route.
        success = self.success_rate if self.success_rate is not None else 0.0
        uptime = self.uptime if self.uptime is not None else 0.0
        rtt = self.remote_rtt_ms if self.remote_rtt_ms is not None else 9999.0
        feedback_boost = 1.0 if self.user_feedback == "good" else 0.0
        feedback_count = min(self.user_good_count, 20) - min(self.user_bad_count, 20)
        return (feedback_boost, float(feedback_count), success, uptime, -rtt)


def _normalise_float(value: Any, scale_100: bool = False) -> float | None:
    try:
        if isinstance(value, str):
            value = value.strip().replace("%", "")
            if not value:
                return None
        result = float(value)
        if result != result or result in (float("inf"), float("-inf")):
            return None
        if scale_100 and result > 1:
            result /= 100.0
        return max(0.0, min(1.0, result))
    except (TypeError, ValueError):
        return None


def parse_proxy_link(line: str, source: str = "") -> ProxyCandidate | None:
    text = line.strip().strip('"\'<>')
    if not text or text.startswith("#"):
        return None
    if "tg://proxy?" not in text and "t.me/proxy?" not in text:
        return None
    try:
        parsed = urllib.parse.urlsplit(text)
        if parsed.scheme == "tg" and parsed.netloc == "proxy":
            query = urllib.parse.parse_qs(parsed.query, strict_parsing=True)
        elif parsed.scheme in ("http", "https") and parsed.netloc.lower() in ("t.me", "telegram.me"):
            if not parsed.path.rstrip("/").endswith("/proxy") and parsed.path.rstrip("/") != "/proxy":
                return None
            query = urllib.parse.parse_qs(parsed.query, strict_parsing=True)
        else:
            return None
        server = query.get("server", [""])[0].strip().strip("[]").rstrip(".")
        port_raw = query.get("port", [""])[0]
        secret = query.get("secret", [""])[0].strip().lower()
        port = int(port_raw)
    except (ValueError, IndexError):
        return None
    if not server or len(server) > 253 or not 1 <= port <= 65535:
        return None
    if not re.fullmatch(r"[a-zA-Z0-9.-]+", server):
        return None
    if server.lower() in {"localhost", "localhost.localdomain"} or server.lower().endswith(".local"):
        return None
    # MTProto secrets: plain 16-byte, dd-prefixed, or ee FakeTLS encoded hex.
    if not re.fullmatch(r"(?:[0-9a-f]{32}|dd[0-9a-f]{32}|ee[0-9a-f]{32,1024})", secret):
        return None
    try:
        ip = ipaddress.ip_address(server)
        if not ip.is_global:
            return None
    except ValueError:
        pass
    candidate = ProxyCandidate(server=server, port=port, secret=secret)
    if source:
        candidate.sources.add(source)
    return candidate


def _iter_records(data: Any) -> Iterable[dict[str, Any]]:
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                yield item
    elif isinstance(data, dict):
        for key in ("endpoints", "proxies", "items", "results", "data"):
            value = data.get(key)
            if isinstance(value, list):
                for item in value:
                    if isinstance(item, dict):
                        yield item
                return
            if isinstance(value, dict):
                for item in value.values():
                    if isinstance(item, dict):
                        yield item
                return
        for item in data.values():
            if isinstance(item, dict) and any(k in item for k in ("server", "host", "hostname")):
                yield item


def _record_candidate(row: dict[str, Any], source: str) -> ProxyCandidate | None:
    server = row.get("server") or row.get("host") or row.get("hostname") or row.get("address")
    port = row.get("port")
    secret = row.get("secret")
    if not server or not port or not secret:
        return None
    try:
        link = f"tg://proxy?server={urllib.parse.quote(str(server), safe='.-')}&port={int(port)}&secret={urllib.parse.quote(str(secret), safe='') }"
    except (TypeError, ValueError):
        return None
    candidate = parse_proxy_link(link, source)
    if not candidate:
        return None
    candidate.metadata = dict(row)
    # These feeds publish periodically health-checked MTProto candidates.
    # Their remote checks are useful evidence, but not proof for this ISP.
    known_checked_lists = {"iwizard-best", "iwizard-stable", "radikal-top100", "pink-mtproto"}
    candidate.verified = bool(
        row.get("verified") is True
        or row.get("status") in ("working", "verified", "stable")
        or source in known_checked_lists
    )
    candidate.success_rate = _normalise_float(row.get("success_rate") if row.get("success_rate") is not None else row.get("uptime"), scale_100=True)
    candidate.uptime = _normalise_float(row.get("uptime"), scale_100=True)
    try:
        rtt = row.get("median_rtt_ms") or row.get("rtt_ms") or row.get("ping")
        candidate.remote_rtt_ms = float(rtt) if rtt is not None else None
    except (TypeError, ValueError):
        candidate.remote_rtt_ms = None
    ads = row.get("ads")
    ads_status = ads.get("status") if isinstance(ads, dict) else row.get("ads_status")
    if ads_status in ("present", "none", "unknown"):
        candidate.ads_status = ads_status
    checked = row.get("last_checked") or row.get("checked_at") or row.get("timestamp")
    candidate.last_checked = str(checked) if checked else None
    return candidate


def merge_candidates(groups: Iterable[Iterable[ProxyCandidate]]) -> list[ProxyCandidate]:
    merged: dict[tuple[str, int, str], ProxyCandidate] = {}
    for group in groups:
        for item in group:
            current = merged.get(item.key)
            if current is None:
                merged[item.key] = item
                continue
            current.sources.update(item.sources)
            current.verified = current.verified or item.verified
            if item.success_rate is not None:
                current.success_rate = max(current.success_rate or 0.0, item.success_rate)
            if item.uptime is not None:
                current.uptime = max(current.uptime or 0.0, item.uptime)
            if item.remote_rtt_ms is not None:
                current.remote_rtt_ms = min(current.remote_rtt_ms or item.remote_rtt_ms, item.remote_rtt_ms)
            # Do not overwrite known 
            if item.ads_status == "present":
                current.ads_status = "present"
            elif item.ads_status == "none" and current.ads_status != "present":
                current.ads_status = "none"
            current.last_checked = item.last_checked or current.last_checked
            if item.metadata:
                current.metadata.update(item.metadata)
    return list(merged.values())


def _download(url: str, timeout: float = 8.0, max_bytes: int = 4 * 1024 * 1024) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "text/plain, application/json"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        data = response.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise ValueError(f"Feed too large: {url}")
    return data


def _parse_feed(name: str, url: str, raw: bytes) -> tuple[list[ProxyCandidate], list[dict[str, Any]]]:
    metadata_rows: list[dict[str, Any]] = []
    if url.endswith(".json"):
        parsed = json.loads(raw.decode("utf-8-sig"))
        rows = list(_iter_records(parsed))
        candidates: list[ProxyCandidate] = []
        for row in rows:
            item = _record_candidate(row, name)
            if item:
                candidates.append(item)
            link = row.get("link") or row.get("url") or row.get("uri")
            if isinstance(link, str):
                from_link = parse_proxy_link(link, name)
                if from_link:
                    candidates.append(from_link)
        metadata_rows = rows
        return candidates, metadata_rows

    text = raw.decode("utf-8-sig", errors="replace")
    candidates = [item for line in text.splitlines() if (item := parse_proxy_link(line, name))]
    if name in {"iwizard-best", "iwizard-stable", "radikal-top100", "pink-mtproto"}:
        for item in candidates:
            item.verified = True
    return candidates, metadata_rows


def refresh_catalog(progress=None) -> tuple[list[ProxyCandidate], dict[str, str]]:
    groups: list[list[ProxyCandidate]] = []
    errors: dict[str, str] = {}
    metadata_rows: list[tuple[str, dict[str, Any]]] = []

    # Independent public feeds are fetched concurrently; a slow endpoint must
    # not block all the other lists for its full timeout.
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, len(FEEDS))) as pool:
        future_names = {pool.submit(_download, url): (name, url) for name, url in FEEDS.items()}
        loaded: dict[str, tuple[list[ProxyCandidate], list[dict[str, Any]]]] = {}
        for future in concurrent.futures.as_completed(future_names):
            name, url = future_names[future]
            try:
                raw = future.result()
                loaded[name] = _parse_feed(name, url, raw)
                if progress:
                    progress(name, len(loaded[name][0]), None)
            except Exception as exc:
                errors[name] = f"{type(exc).__name__}: {exc}"[:240]
                if progress:
                    progress(name, 0, errors[name])

    # Keep deterministic source order for reproducible ties and local probes.
    for name in FEEDS:
        if name in loaded:
            candidates, rows = loaded[name]
            groups.append(candidates)
            metadata_rows.extend((name, row) for row in rows)

    result = merge_candidates(groups)
    # Metadata feeds sometimes identify a proxy by host + port. Do not apply
    # those facts to multiple different secrets on the same endpoint.
    meta_by_host_port: dict[tuple[str, int], list[tuple[str, dict[str, Any]]]] = {}
    for source, row in metadata_rows:
        host = row.get("server") or row.get("host") or row.get("hostname") or row.get("address")
        try:
            port = int(row.get("port"))
        except (TypeError, ValueError):
            continue
        if host:
            meta_by_host_port.setdefault((str(host).lower().rstrip("."), port), []).append((source, row))
    secrets_per_endpoint: dict[tuple[str, int], set[str]] = {}
    for candidate in result:
        secrets_per_endpoint.setdefault((candidate.server.lower().rstrip("."), candidate.port), set()).add(candidate.secret.lower())
    for candidate in result:
        endpoint_key = (candidate.server.lower().rstrip("."), candidate.port)
        for source, row in meta_by_host_port.get(endpoint_key, []):
            row_secret = str(row.get("secret") or "").strip().lower()
            if row_secret and row_secret != candidate.secret.lower():
                continue
            if not row_secret and len(secrets_per_endpoint.get(endpoint_key, set())) > 1:
                continue
            candidate.metadata.update(row)
            candidate.sources.add(source)
            candidate.verified = candidate.verified or row.get("verified") is True or row.get("status") in ("working", "verified", "stable") or source in {"iwizard-best", "iwizard-stable", "radikal-top100", "pink-mtproto"}
            success = _normalise_float(row.get("success_rate"), scale_100=True)
            if success is not None:
                candidate.success_rate = max(candidate.success_rate or 0.0, success)
            uptime = _normalise_float(row.get("uptime"), scale_100=True)
            if uptime is not None:
                candidate.uptime = max(candidate.uptime or 0.0, uptime)
            try:
                rtt = row.get("median_rtt_ms") or row.get("rtt_ms") or row.get("ping")
                if rtt is not None:
                    candidate.remote_rtt_ms = float(rtt)
            except (TypeError, ValueError):
                pass
            ads = row.get("ads")
            ads_status = ads.get("status") if isinstance(ads, dict) else row.get("ads_status")
            if ads_status in ("present", "none", "unknown"):
                if ads_status == "present" or candidate.ads_status != "present":
                    candidate.ads_status = ads_status
    return rank_candidates(result), errors


def rank_candidates(items: Iterable[ProxyCandidate]) -> list[ProxyCandidate]:
    return sorted(items, key=lambda p: (p.eligible_for_auto, *p.rank_tuple()), reverse=True)


def is_probeable_public_ip(host: str) -> bool:
    """Return True only for literal globally-routable IPs suitable for safe TCP probes."""
    try:
        return ipaddress.ip_address(host).is_global
    except ValueError:
        return False


def select_probe_batch(candidates: Iterable[ProxyCandidate], limit: int = 24) -> list[ProxyCandidate]:
    """Select the best-ranked public-IP candidates without spending quota on DNS names."""
    bounded_limit = max(0, min(int(limit), 256))
    if bounded_limit == 0:
        return []
    return [candidate for candidate in candidates if is_probeable_public_ip(candidate.server)][:bounded_limit]


def probe_tcp(candidate: ProxyCandidate, timeout: float = 1.6) -> ProxyCandidate:
    """Bounded TCP reachability prefilter for public IP proxies only.

    Hostname resolution can block independently of a socket timeout. To keep
    the desktop UI responsive and avoid unsafe DNS destinations, ART only
    performs automatic preflight probes for literal globally-routable IPs.
    Hostname candidates remain available for manual use.
    """
    started = time.perf_counter()
    try:
        ip = ipaddress.ip_address(candidate.server)
    except ValueError:
        candidate.local_reachable = None
        candidate.local_tcp_ms = None
        candidate.metadata["local_probe_error"] = "DNS probe skipped for hostname"
        return candidate

    if not is_probeable_public_ip(candidate.server):
        candidate.local_reachable = False
        candidate.local_tcp_ms = None
        candidate.metadata["local_probe_error"] = "Non-public IP skipped"
        return candidate

    try:
        with socket.create_connection((ip.compressed, candidate.port), timeout=timeout):
            candidate.local_reachable = True
    except OSError as exc:
        candidate.local_reachable = False
        candidate.metadata["local_probe_error"] = str(exc)[:120]
    candidate.local_tcp_ms = round((time.perf_counter() - started) * 1000, 1)
    return candidate


def open_proxy_link(candidate: ProxyCandidate) -> str:
    return (
        "tg://proxy?server=" + urllib.parse.quote(candidate.server, safe=".-")
        + "&port=" + str(candidate.port)
        + "&secret=" + urllib.parse.quote(candidate.secret, safe="")
    )
