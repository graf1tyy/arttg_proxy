from __future__ import annotations

import json
import os
import re
import secrets
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Any


def app_data_dir() -> Path:
    root = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
    if root:
        path = Path(root) / "ART"
    else:
        path = Path.home() / ".art"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _valid_domain(value: str) -> bool:
    if not value or len(value) > 253:
        return False
    labels = value.split(".")
    return all(
        1 <= len(label) <= 63
        and re.fullmatch(r"[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", label) is not None
        for label in labels
    )


@dataclass
class AppConfig:
    host: str = "127.0.0.1"
    port: int = 1443
    secret: str = ""
    pool_size: int = 4
    buffer_kb: int = 256
    cloudflare_enabled: bool = True
    media_h2_enabled: bool = True
    worker_domains: tuple[str, ...] = ()
    cloudflare_domains: tuple[str, ...] = ()
    auto_open_telegram: bool = True
    auto_refresh_minutes: int = 120

    def normalise(self) -> "AppConfig":
        # ART deliberately exposes the local listener only on loopback.
        self.host = "127.0.0.1"
        if not isinstance(self.port, int) or not 1024 <= self.port <= 65535:
            self.port = 1443
        if not isinstance(self.secret, str) or len(self.secret) != 32 or any(c not in "0123456789abcdefABCDEF" for c in self.secret):
            self.secret = secrets.token_hex(16)
        if not isinstance(self.pool_size, int) or not 0 <= self.pool_size <= 32:
            self.pool_size = 4
        if not isinstance(self.buffer_kb, int) or not 16 <= self.buffer_kb <= 8192:
            self.buffer_kb = 256
        self.cloudflare_enabled = bool(self.cloudflare_enabled)
        self.media_h2_enabled = bool(self.media_h2_enabled)
        if not isinstance(self.worker_domains, (tuple, list)):
            self.worker_domains = ()
        clean_domains: list[str] = []
        for raw in self.worker_domains:
            domain = str(raw).strip().lower().rstrip(".")
            if _valid_domain(domain):
                clean_domains.append(domain)
        self.worker_domains = tuple(dict.fromkeys(clean_domains))
        if not isinstance(self.cloudflare_domains, (tuple, list)):
            self.cloudflare_domains = ()
        clean_cf: list[str] = []
        for raw in self.cloudflare_domains:
            domain = str(raw).strip().lower().rstrip(".")
            if _valid_domain(domain):
                clean_cf.append(domain)
        self.cloudflare_domains = tuple(dict.fromkeys(clean_cf))
        if not isinstance(self.auto_refresh_minutes, int) or not 15 <= self.auto_refresh_minutes <= 1440:
            self.auto_refresh_minutes = 120
        self.auto_open_telegram = bool(self.auto_open_telegram)
        return self


def config_path() -> Path:
    return app_data_dir() / "settings.json"


def load_config(path: Path | None = None) -> AppConfig:
    target = path or config_path()
    if not target.exists():
        cfg = AppConfig().normalise()
        save_config(cfg, target)
        return cfg
    try:
        raw = json.loads(target.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("Settings root must be a JSON object")
        allowed = {f.name for f in fields(AppConfig)}
        data = {k: v for k, v in raw.items() if k in allowed}
        if isinstance(data.get("worker_domains"), list):
            data["worker_domains"] = tuple(data["worker_domains"])
        if isinstance(data.get("cloudflare_domains"), list):
            data["cloudflare_domains"] = tuple(data["cloudflare_domains"])
        return AppConfig(**data).normalise()
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        try:
            stamp = int(target.stat().st_mtime)
        except OSError:
            stamp = 0
        backup = target.with_name(f"settings.invalid.{stamp}.json")
        try:
            target.replace(backup)
        except OSError:
            pass
        cfg = AppConfig().normalise()
        save_config(cfg, target)
        return cfg


def save_config(config: AppConfig, path: Path | None = None) -> None:
    target = path or config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    config.normalise()
    payload = asdict(config)
    payload["worker_domains"] = list(config.worker_domains)
    payload["cloudflare_domains"] = list(config.cloudflare_domains)
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    temp.replace(target)
